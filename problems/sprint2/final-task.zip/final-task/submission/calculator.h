// Ваше решение задачи о калькуляторе с классом.
#pragma once
#include <cmath>

using Number = double;

bool ReadNumber(Number& result);

bool RunCalculatorCycle ();

class Calculator {
public:
    void SetLeftOperand(Number value){
        left_operand_ = value;
    }
    Number GetLeftOperand(){
        return left_operand_;
    }
    Number Add(Number right_operand) const {
        return left_operand_ + right_operand;
    }
    Number Sub(Number right_operand) const {
        return left_operand_ - right_operand;
    }
    Number Mul(Number right_operand) const {
        return left_operand_ * right_operand;
    }
    Number Div(Number right_operand) const {
        if (right_operand == 0){
            return 1;
        }
        return left_operand_ / right_operand;
    }
    Number Pow(Number right_operand) const {
        return pow(left_operand_, right_operand);
    }

private:
    Number left_operand_ = 0.0;
};
